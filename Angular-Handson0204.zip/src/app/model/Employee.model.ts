import {Department} from "./Department.model";
import {Skill} from "./Skill.model";

export interface Employee {
  id: number;
  name: string;
  salary: number;
  permanent: boolean;
  department: Department;
  skill: Skill[];
  dateOfBirth: Date;
}
