import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AppComponent} from './app.component';
import {EditEmployeeComponent} from './edit-employee/edit-employee.component';
import {ViewEmployeeComponent} from './view-employee/view-employee.component';
import {QuantityIncreamentComponent} from "./quantity-increament/quantity-increament.component";

const routes: Routes = [
  {path: 'viewEmployee', component: ViewEmployeeComponent},
  {path: 'editEmployee', component: EditEmployeeComponent},
  {path: 'quantityIncrement', component: QuantityIncreamentComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
